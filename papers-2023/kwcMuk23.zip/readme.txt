Markup UK 2023 submission manifest

From:

  Kurt Conrad
  conrad@sagebrushgroup.com
  408.390.0999


Title:  Word processing is so last century


Primary files:

  readme.txt                        this manifest
  kwcWPmuk23paperDB_20230531.pdf    DocBook rendering
  kwcWPmuk23paperDB_20230531.xml    DocBook xml
  /img/*                            supporting images


Secondary files:

  srcWPMuk23paper_20230531.pdoc     authored source
  srcWPMuk23paper_20230531.pdf      authored rendering
  pdoc2docbook.xsl                  generates DocBook

